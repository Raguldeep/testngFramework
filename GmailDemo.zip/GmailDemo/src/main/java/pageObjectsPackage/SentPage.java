package pageObjectsPackage;

public class SentPage {

}
